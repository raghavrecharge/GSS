BODHLOK 3D WIDGET LIBRARY

46 separate PNG assets. Open index.html to browse, filter and download each file.
All PNGs contain alpha transparency and retain their generated original resolution.

Coverage: charts and planetary tables, KP, Jaimini, BNN, dasha and gochar timing, Panchang, muhurta, strength and balance, reports and yogas, consultations, Why Me and My Practice.

These are AI-generated 3D presentations based on original software screenshots, not pixel-exact UI exports. Use them as visual assets; the live software remains the source for chart data and calculations.

asset-list.json records dimensions, file sizes, checksums and source screenshot paths. generation-manifest.json records generation instructions. validation.json records the PNG integrity and transparency audit.
